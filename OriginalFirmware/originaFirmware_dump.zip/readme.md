```
admin@AFOUNDRY-4FF830:/proc# cat mtd
dev:    size   erasesize  name
mtd0: 01000000 00010000 "ALL"
mtd1: 00030000 00010000 "Bootloader"
mtd2: 00010000 00010000 "Config"
mtd3: 00010000 00010000 "Factory"
mtd4: 00fb0000 00010000 "firmware"
mtd5: 00e789d5 00010000 "rootfs"
mtd6: 00920000 00010000 "rootfs_data"
```

```
[xnn@xNN-Octacore uno]$ sudo binwalk mtd0

DECIMAL       HEXADECIMAL     DESCRIPTION
--------------------------------------------------------------------------------
75840         0x12840         U-Boot version string, "U-Boot 1.1.3 (Nov  8 2016 - 17:27:55)"
327680        0x50000         uImage header, header size: 64 bytes, header CRC: 0xB484A65A, created: 2016-11-08 09:27:43, image size: 1275371 bytes, Data Address: 0x80000000, Entry Point: 0x80000000, data CRC: 0xCFB8CA1E, OS: Linux, CPU: MIPS, image type: OS Kernel Image, compression type: lzma, image name: "OpenWrt Linux-3.10.14"
327744        0x50040         LZMA compressed data, properties: 0x6D, dictionary size: 8388608 bytes, uncompressed size: 3684732 bytes
1603115       0x18762B        Squashfs filesystem, little endian, version 4.0, compression:xz, size: 5565342 bytes, 1208 inodes, blocksize: 262144 bytes, created: 2016-11-08 09:27:41
7208960       0x6E0000        JFFS2 filesystem, little endian

```
