iwpriv ra0 set hw_nat_register=0
iwpriv rai0 set hw_nat_register=0
rmmod hw_nat.ko

