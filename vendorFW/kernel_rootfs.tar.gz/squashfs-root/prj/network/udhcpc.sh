#!/bin/sh

env >/var/.prj_var/network/${interface}-udhcpc.env

# for $routes
set_dhcp_routes() {
    local max=128
    local host
    local gw
    while [ -n "$1" -a $max -gt 0 ]; do 
        host=${1%%/*}
        gw=${1##*/}
        logger "udhcpc: adding route for $host via $gw"
        route add -host "$host" gw "$gw" dev "$interface"
        #max=$(($max-1)) 
        max=`expr $max-1`
        shift 1
    done
}
# for $staticroutes $msstaticroutes
set_classless_routes() {
    local max=128
    local type
    while [ -n "$1" -a -n "$2" -a $max -gt 0 ]; do
        [ ${1##*/} -eq 32 ] && type=host || type=net
        logger "udhcpc: adding route for $type $1 via $2"
        route add -$type "$1" gw "$2" dev "$interface"
        #max=$(($max-1))
        max=`expr $max-1`
        shift 2
    done
}

case $1 in

    deconfig)
        ifconfig ${interface} 0.0.0.0 up
    ;;

    leasefail)
        #cronos ifname.down[${interface}]
        /bin/logger "Lease failed: $message"
    ;;

    nak)
        /bin/logger "Received a NAK: $message"
    ;;

    bound)
        /bin/logger "udhcpc reset the ip($oldip:$ip) or gateway($oldgw:$router)"
        [ -n "$broadcast" ] && BROADCAST="broadcast $broadcast"
        [ -n "$subnet" ] && NETMASK="netmask $subnet"
        ifconfig ${interface} $ip $BROADCAST $NETMASK up
        arping -U -c 1 -I ${interface} $ip

        # record
        [ -n "$ip" ] && echo "$ip" > /var/.prj_var/network/${interface}-udhcpc.ip
        [ -n "$router" ] && echo "$router" > /var/.prj_var/network/${interface}-udhcpc.gw
        [ -n "$dns" ] && echo "$dns" > /var/.prj_var/network/${interface}-udhcpc.dns
        
        # Update resolver configuration file
        dns1=`echo ${dns}|awk -F '[, :;]' '{print $1}'`
        dns2=`echo ${dns}|awk -F '[, :;]' '{print $2}'`
        ONLINEINFO="{\"mode\":\"dhcpc\",\"device\":\"${interface}\",\"gw\":\"${router}\",\"dns\":\"${dns1}\",\"dns2\":\"${dns2}\"}"
        /bin/logger "network/frame.online[${ONLINEINFO}]"
        he "network/frame.online[${ONLINEINFO}]"

        # CIDR STATIC ROUTES (rfc3442)
        [ -n "$staticroutes" ] && set_classless_routes $staticroutes
        [ -n "$msstaticroutes" ] && set_classless_routes $msstaticroutes
    ;;

    renew)
        local oldip="";
        if [ -f /var/.prj_var/network/${interface}-udhcpc.ip ]
        then \
            oldip=`cat /var/.prj_var/network/${interface}-udhcpc.ip`
        fi
        local oldgw="";
        if [ -f /var/.prj_var/network/${interface}-udhcpc.gw ]
        then \
            oldgw=`cat /var/.prj_var/network/${interface}-udhcpc.gw`
        fi
        local olddns="";
        if [ -f /var/.prj_var/network/${interface}-udhcpc.dns ]
        then \
            olddns=`cat /var/.prj_var/network/${interface}-udhcpc.dns`
        fi
        if [ "X$oldip" != "X$ip" ] || [ "X$oldgw" != "X$router" ] || [ "X$olddns" != "X$dns" ]
        then
            /bin/logger "udhcpc renew the ip($oldip:$ip) or gateway($oldgw:$router)"
            [ -n "$broadcast" ] && BROADCAST="broadcast $broadcast"
            [ -n "$subnet" ] && NETMASK="netmask $subnet"
            ifconfig ${interface} $ip $BROADCAST $NETMASK up
            arping -U -c 1 -I ${interface} $ip

            # record
            [ -n "$ip" ] && echo "$ip" > /var/.prj_var/network/${interface}-udhcpc.ip
            [ -n "$router" ] && echo "$router" > /var/.prj_var/network/${interface}-udhcpc.gw
            [ -n "$dns" ] && echo "$dns" > /var/.prj_var/network/${interface}-udhcpc.dns
            
            # Update resolver configuration file
            dns1=`echo ${dns}|awk -F '[, :;]' '{print $1}'`
            dns2=`echo ${dns}|awk -F '[, :;]' '{print $2}'`
            ONLINEINFO="{\"mode\":\"dhcpc\",\"device\":\"${interface}\",\"gw\":\"${router}\",\"dns\":\"${dns1}\",\"dns2\":\"${dns2}\"}"
            /bin/logger "network/frame.online[${ONLINEINFO}]"
            he "network/frame.online[${ONLINEINFO}]"
    
            # CIDR STATIC ROUTES (rfc3442)
            [ -n "$staticroutes" ] && set_classless_routes $staticroutes
            [ -n "$msstaticroutes" ] && set_classless_routes $msstaticroutes
        fi
esac

