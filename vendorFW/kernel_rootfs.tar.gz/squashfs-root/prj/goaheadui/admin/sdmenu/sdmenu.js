
function SDMenu(id) {
	if (!document.getElementById || !document.getElementsByTagName)
		return false;
	this.menu = document.getElementById(id);
	this.submenus = this.menu.getElementsByTagName("div");
	this.remember = false;
	this.speed = 6;
	this.markCurrent = true;
	this.oneSmOnly = false;
}
SDMenu.prototype.init = function() {
	var mainInstance = this;
	for (var i = 0; i < this.submenus.length; i++) {
		// add by yibo
		if (this.submenus[i].getElementsByTagName("a").length > 1) {
			if (typeof(this.submenus[i].getElementsByClassName("collapse_indication")[0]) != "undefined") {
				this.submenus[i].getElementsByClassName("collapse_indication")[0].innerHTML = "+";
			}
		}
		this.submenus[i].getElementsByTagName("span")[0].onclick = function() {
			mainInstance.toggleMenu(this.parentNode);
			// add by yibo
			var link_t = this.parentNode.getElementsByTagName("a");
			if (link_t.length == 1) {
				link_t[0].click();
			} else {
				var j = 0;
				for (j = 0; j < link_t.length; j++) {
					if (link_t[j].style.display != "none") {
						link_t[j].click();
						break;
					}
				}
				if (j >= link_t.length) {
					link_t[0].click();
				}
			}
			// add end
		};
	}
	if (this.markCurrent) {
		var links = this.menu.getElementsByTagName("a");
		for (var i = 0; i < links.length; i++){
//			links[0].className="current";
			
			links[i].onclick = function() {
				var link_t = document.getElementsByTagName("a");
				for (var i = 0; i < link_t.length; i++){
					if(link_t[i].className== "current"){
						link_t[i].className='';
					}
				}
				this.className = "current";
		}
			//if (links[i].href == sampleframe.location.href) {
			//	links[i].className = "current";
			//	break;
			//}
		}
	}
	if (this.remember) {
		var regex = new RegExp("sdmenu_" + encodeURIComponent(this.menu.id) + "=([01]+)");
		var match = regex.exec(document.cookie);
		if (match) {
			var states = match[1].split("");
			for (var i = 0; i < states.length; i++)
				this.submenus[i].className = (states[i] == 0 ? "collapsed" : "");
		}
	}
};
SDMenu.prototype.toggleMenu = function(submenu) {
	if (submenu.className == "collapsed")
		this.expandMenu(submenu);
	else
		this.collapseMenu(submenu);
};
// add by yibo
SDMenu.prototype.changeIndication = function(submenu) {
	if (typeof(submenu.getElementsByClassName("collapse_indication")[0]) != "undefined") {
		if (submenu.className != "collapsed") {
			submenu.getElementsByClassName("collapse_indication")[0].innerHTML = "-";
		} else {
			submenu.getElementsByClassName("collapse_indication")[0].innerHTML = "+";
		}
	}
}
SDMenu.prototype.expandMenu = function(submenu) {
	// add by yibo
	submenu.getElementsByTagName("span")[0].click();
	// end
	var fullHeight = submenu.getElementsByTagName("span")[0].offsetHeight;
	var links = submenu.getElementsByTagName("a");
	for (var i = 0; i < links.length; i++)
		fullHeight += links[i].offsetHeight;
	var moveBy = Math.round(this.speed * links.length);
	
	var mainInstance = this;
	var intId = setInterval(function() {
		var curHeight = submenu.offsetHeight;
		var newHeight = curHeight + moveBy;
		if (newHeight < fullHeight)
			submenu.style.height = newHeight + "px";
		else {
			clearInterval(intId);
			submenu.style.height = "";
			submenu.className = "expand";
			mainInstance.memorize();
			mainInstance.changeIndication(submenu);
		}
	}, 30);
	this.collapseOthers(submenu);
};
SDMenu.prototype.collapseMenu = function(submenu) {
	var minHeight = submenu.getElementsByTagName("span")[0].offsetHeight;
	var moveBy = Math.round(this.speed * submenu.getElementsByTagName("a").length);
	var mainInstance = this;
	var intId = setInterval(function() {
		var curHeight = submenu.offsetHeight;
		var newHeight = curHeight - moveBy;
		if (newHeight > minHeight)
			submenu.style.height = newHeight + "px";
		else {
			clearInterval(intId);
			submenu.style.height = "";
			submenu.className = "collapsed";
			mainInstance.memorize();
			mainInstance.changeIndication(submenu);
		}
	}, 30);
};
SDMenu.prototype.collapseOthers = function(submenu) {
	if (this.oneSmOnly) {
		for (var i = 0; i < this.submenus.length; i++)
			if (this.submenus[i] != submenu && this.submenus[i].className != "collapsed")
				this.collapseMenu(this.submenus[i]);
	}
};
SDMenu.prototype.expandAll = function() {
	var oldOneSmOnly = this.oneSmOnly;
	this.oneSmOnly = true;
	for (var i = 0; i < this.submenus.length; i++)
		if (this.submenus[i].className == "collapsed")
			this.expandMenu(this.submenus[i]);
	this.oneSmOnly = oldOneSmOnly;
};
SDMenu.prototype.collapseAll = function() {
	for (var i = 0; i < this.submenus.length; i++)
		if (this.submenus[i].className != "collapsed")
			this.collapseMenu(this.submenus[i]);
};
// download by http://www.codefans.net
SDMenu.prototype.memorize = function() {
	if (this.remember) {
		var states = new Array();
		for (var i = 0; i < this.submenus.length; i++)
			states.push(this.submenus[i].className == "collapsed" ? 0 : 1);
		var d = new Date();
		d.setTime(d.getTime() + (30 * 24 * 60 * 60 * 1000));
		document.cookie = "sdmenu_" + encodeURIComponent(this.menu.id) + "=" + states.join("") + "; expires=" + d.toGMTString() + "; path=/";
	}
};

