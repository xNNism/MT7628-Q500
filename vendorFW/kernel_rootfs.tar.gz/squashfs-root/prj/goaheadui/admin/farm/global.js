


/**
*
*  Base64 encode / decode
*  http://www.webtoolkit.info/
*
**/
var Base64 = {

    // private property
    _keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",

    // public method for encoding
    encode : function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;

        input = Base64._utf8_encode(input);

        while (i < input.length) {

            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);

            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;

            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }

            output = output +
            this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
            this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);

        }

        return output;
    },

    // public method for decoding
    decode : function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;

        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

        while (i < input.length) {

            enc1 = this._keyStr.indexOf(input.charAt(i++));
            enc2 = this._keyStr.indexOf(input.charAt(i++));
            enc3 = this._keyStr.indexOf(input.charAt(i++));
            enc4 = this._keyStr.indexOf(input.charAt(i++));

            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;

            output = output + String.fromCharCode(chr1);

            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }

        }

        output = Base64._utf8_decode(output);

        return output;

    },

    // private method for UTF-8 encoding
    _utf8_encode : function (string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";

        for (var n = 0; n < string.length; n++) {

            var c = string.charCodeAt(n);

            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }

        return utftext;
    },

    // private method for UTF-8 decoding
    _utf8_decode : function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;

        while ( i < utftext.length ) {

            c = utftext.charCodeAt(i);

            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i+1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i+1);
                c3 = utftext.charCodeAt(i+2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }

        }

        return string;
    }

}

/* UrlEncode/UrlDecode */
function str2asc(strstr)
{
    return ("0"+strstr.charCodeAt(0).toString(16)).slice(-2);
}
function asc2str(ascasc)
{
    return String.fromCharCode(ascasc);
}
function UrlEncode( str )
{
    var ret="";
    var strSpecial="!\"#$%&'()*+,/:;<=>?[]^`{|}~%";
    var tt= "";

    for(var i=0;i<str.length;i++)
    {
        var chr = str.charAt(i);
        var c=str2asc(chr);
        tt += chr+":"+c+"n";
        if(parseInt("0x"+c) > 0x7f)
        {
            ret+="%"+c.slice(0,2)+"%"+c.slice(-2);
        }
        else
        {
            if(chr==" ")
                ret+="+";
            else if(strSpecial.indexOf(chr)!=-1)
                ret+="%"+c.toString(16);
            else
                ret+=chr;
        }
    }
    return ret;
}
function UrlDecode( str )
{
    var ret="";

    for(var i=0;i<str.length;i++)
    {
        var chr = str.charAt(i);
        if(chr == "+")
        {
            ret+=" ";
        }
        else if(chr=="%")
        {
            var asc = str.substring(i+1,i+3);
            if( parseInt("0x"+asc)>0x7f)
            {
                ret+=asc2str(parseInt("0x"+asc+str.substring(i+4,i+6)));
                i+=5;

            }
            else
            {
                ret+=asc2str(parseInt("0x"+asc));
                i+=2;
            }
        }
        else
        {
            ret+= chr;
        }
    }
    return ret;
}

/* Cookie */
function CookieSet(name, value)
{
    var argv = setCookie.arguments;
    var argc = setCookie.arguments.length;
    var expires = (argc > 2) ? argv[2] : null;
    if(expires!=null)
    {
        var LargeExpDate = new Date ();
        LargeExpDate.setTime(LargeExpDate.getTime() + (expires*1000*3600*24));
    }
    document.cookie = name + "=" + escape (value)+((expires == null) ? "" : ("; expires=" +LargeExpDate.toGMTString()));
}
function CookieGet(Name)
{
    var search = Name + "="
    if(document.cookie.length > 0)
    {
        offset = document.cookie.indexOf(search)
        if(offset != -1)
        {
            offset += search.length
            end = document.cookie.indexOf(";", offset)
            if(end == -1) end = document.cookie.length
            return unescape(document.cookie.substring(offset, end))
        }
        else return ""
    }
}
function CookieDelete(name)
{
    var expdate = new Date();
    expdate.setTime(expdate.getTime() - (86400 * 1000 * 1));
    setCookie(name, "", expdate);
}

/* url prarmeter */
function UrlParam( paramName )
{
    var oregex = new RegExp( '[\?&]' + paramName + '=([^&]+)', 'i' ) ;
    var oMatch = oregex.exec( window.location.search ) ;

    if ( oMatch && oMatch.length > 1 )
      return decodeURIComponent( oMatch[1] ) ;
    else
      return '' ;
}

/* ie type get */
function IeGet()
{
    var OsObject = "";
    if(navigator.userAgent.indexOf("MSIE")>0)
    {
        return "ie";
    }
    if(isFirefox=navigator.userAgent.indexOf("Firefox")>0)
    {
        return "firefox";
    }
    if(isSafari=navigator.userAgent.indexOf("Safari")>0)
    {
        return "safari";
    }
    if(isCamino=navigator.userAgent.indexOf("Camino")>0)
    {
        return "camino";
    }
    if(isMozilla=navigator.userAgent.indexOf("Gecko/")>0)
    {
        return "gecko";
    }
    return "unknow";
}
function IeLanguage()
{
    var lang = "en";

    try
    {
        lang = navigator.browserLanguage.toLowerCase() == "zh-cn"?"cn":"en";
    }
    catch(e)
    {
        try
        {
            lang = navigator.language.toLowerCase() == "zh-cn"?"cn":"en";
        }catch(e){}
    }
    return lang;
}

/* cgi interface */
function He( a, func )
{
    var ret;
    var uri;
    var paramter;
    var i;
    var t;
    var hekey;
    var heindex;
    var htmlobj;
    var callbak;

    if ( a == null )
    {
        return null;
    }
    /* get the uri */
    uri = "/action/he?rand="+Math.random();
    paramter = "";
    /* get the paramter */
    heindex = null;
    if ( a instanceof Array )
    {
        heindex = new Array();
        t = 0;
        for( i in a )
        {
            if ( t == 0 )
            {
                hekey = "he";
            }
            else
            {
                hekey = "he"+t;
            }
            paramter += ( "&"+hekey+"="+UrlEncode( Base64.encode(a[i]) ) );
            heindex[ hekey] = i;
            t++;
        }
    }
    else if ( a instanceof Object )
    {
        heindex = new Object();
        t = 0;
        for( i in a )
        {
            if ( t == 0 )
            {
                hekey = "he";
            }
            else
            {
                hekey = "he"+t;
            }
            paramter += ( "&"+hekey+"="+UrlEncode( Base64.encode(a[i]) ) );
            heindex[ hekey] = i;
            t++;
        }
    }
    else
    {
        paramter = "&he="+UrlEncode( Base64.encode(a) );
    }
    if ( paramter == null || paramter == "" )
    {
        return null;
    }
    /* get the async */
    if ( func != null )
    {
        $.ajax( { 'url':uri, 'type':'POST', 'contentType':'application/x-www-form-urlencoded', 'data':paramter, 'async':true, 'complete':function(x,s)
        {
            paramter = Base64.decode( x.responseText )
            callbak = eval("(" + paramter + ")");
            if ( callbak == null )
            {
                ret = null;
            }
            else if ( heindex == null )
            {
                ret = callbak.he;
                if ( callbak["he"] == "TTRUE" )
                {
                    ret = true;
                }
                else if ( callbak["he"] == "TFALSE" )
                {
                    ret = false;
                }
            }
            else
            {
                var value = new Object();
                for ( i in heindex )
                {
                    if ( typeof callbak[i] == "string" )
                    {
                        if ( callbak[i] == "TTRUE" )
                        {
                            value[ heindex[i] ] = true;
                            continue;
                        }
                        else if ( callbak[i] == "TFALSE" )
                        {
                            value[ heindex[i] ] = false;
                            continue;
                        }
                    }
                    value[ heindex[i] ] = callbak[i];
                }
                ret = value;
            }
            func( ret );
        } } );
    }
    else
    {
        htmlobj=$.ajax( { 'url':uri, 'type':'POST', 'contentType':'application/x-www-form-urlencoded', 'data':paramter, 'async':false } );
        paramter = Base64.decode( htmlobj.responseText )
        callbak = eval("(" + paramter + ")");
        if ( callbak == null )
        {
            ret = null;
        }
        else if ( heindex == null )
        {
            ret = callbak.he;
            if ( callbak["he"] == "TTRUE" )
            {
                ret = true;
            }
            else if ( callbak["he"] == "TFALSE" )
            {
                ret = false;
            }
        }
        else
        {
            var value = new Object();
            for ( i in heindex )
            {
                if ( typeof callbak[i] == "string" )
                {
                    if ( callbak[i] == "TTRUE" )
                    {
                        value[ heindex[i] ] = true;
                        continue;
                    }
                    else if ( callbak[i] == "TFALSE" )
                    {
                        value[ heindex[i] ] = false;
                        continue;
                    }
                }
                value[ heindex[i] ] = callbak[i];
            }
            ret = value;
        }
        return ret;
    }
}



/* value tools */
function IsEmpty( value )
{
    if ( value == "undefined" || value == null ||value == "" )
    {
        return true;
    }
    return false;
}
function IsNumber(input)
{
     var pattern = /^[0-9]+.?[0-9]*$/;
     if (!pattern.test(input))
    {
        return false;
     }
     return true;
}
function IsXnumber(input)
{
     var pattern = /^[0-9a-fA-F]+.?[0-9a-fA-F]*$/;
     if (!pattern.test(input))
    {
        return false;
     }
     return true;
}
function IsIpAddress(value)
{
    var pattern = /^\d{1,3}(\.\d{1,3}){3}$/;
    if (!pattern.exec(value))
    {
        return false;
    }

    var ary = value.split('.');
    for(key in ary)
    {
        if (parseInt(ary[key]) > 255)
        {
            return false;
        }
    }
    return true;
}
function IsMac( mac )
{
    var pattern=/[a-fA-F\d]{2}:[a-fA-F\d]{2}:[a-fA-F\d]{2}:[a-fA-F\d]{2}:[a-fA-F\d]{2}:[a-fA-F\d]{2}/;
    if(!pattern.test(mac))
    {
        return false;
    }
    return true;
}
function EmptyToSpace( value )
{
    if ( value == "undefined" || value == null ||value == "" )
    {
        return "";
    }
    return value;
}
function EmptyToIt( value, exp )
{
    if ( value == "undefined" || value == null ||value == "" )
    {
        return exp;
    }
    return value;
}
function JsonString( jsonobj )
{
    return JSON.stringify( jsonobj );
}
function StringJson( string )
{
    return eval("(" + string + ")");
}
function JsonClone( fobj )
{
    var ret;
    var string;

    try
    {
        string = JsonString( fobj );
        ret = StringJson( string );
    }
    catch(E)
    {
        alert("JsonClone->JsonString/StringJson: " + E + "\n" + string );
        return;
    }
    return ret;
}
function ObjectSize( fobj )
{
    var count;
    count = 0;
    for (var ele in fobj )
    {
        count++;
    }
    return count;
}
function ArrayEqual( farr,sarr )
{
    if ( farr.length != sarr.length )
    {
        return false;
    }
    for ( var i = 0; i < farr.length; i++ )
    {
        if ( !JsonEqual( farr[i], sarr[i] ) )
        {
            return false;
        }
    }
    return true;
}
function ObjectEqual( fobj,sobj )
{
    if ( ObjectSize( fobj ) != ObjectSize( sobj ) )
    {
        return false;
    }
    for ( var ele in fobj )
    {
        if ( sobj[ele] == undefined )
        {
            return false;
        }
        if ( !JsonEqual( fobj[ele], sobj[ele] ) )
        {
            return false;
        }
    }
    return true;
}
function JsonEqual( fobj,sobj )
{
    var ftype = typeof(fobj);
    var stype = typeof(sobj);

    if (ftype == stype)
    {
        if (ftype == "object")
        {
            return ObjectEqual(fobj,sobj);
        }
        else if ( ftype == "array" )
        {
            return ArrayEqual(fobj,sobj)
        }
        return fobj == sobj;
    }
    return false;
}



/* Radio operation for set */
function RadioSet( name, value )
{
    var i;
    var tmp;

    if ( IsEmpty(value) == true )
    {
        tmp = document.getElementsByName( name );
        for ( i=0; i<tmp.length; i++ )
        {
            tmp[i].checked = false;
        }
    }
    else
    {
        tmp = document.getElementsByName( name );
        for ( i=0; i<tmp.length; i++ )
        {
            if ( value == tmp[i].value )
            {
                tmp[i].checked = true;
            }
        }
    }
}
/* Radio operation for get */
function RadioGet( name )
{
    var i;
    var tmp;

     tmp = document.getElementsByName( name );
     for ( i=0; i<tmp.length; i++ )
    {
        if ( tmp[i].checked == true )
        {
            return tmp[i].value;
        }
    }
    return "";
}

/* get id object at html */
function Id()
{
    var elements = new Array();

    for( var i = 0; i < arguments.length; i++ )
    {
        var element = arguments[i];
        if ( typeof element == 'string' )
        {
            if ( document.getElementById )
            {
                element = document.getElementById( element );
            }
            else if( document.all )
            {
                element = document.all[ element ];
            }
        }
        elements.push( element );
    }
    if( arguments.length == 1 && elements.length > 0)
    {
        return elements[0];
    }
    else
    {
        return elements;
    }
}

/* parse the js and fill the langauge to id */
function FillLang( obj, notitle )
{
    for( var attr in obj )
    {
        try
        {
            switch( attr )
            {
                case "title":
                    if ( notitle != true )
                    {
                        document.title = obj[ attr ];
                        if ( top != null && top.Title != null )
                        {
                            top.Title( obj[ attr ] );
                        }
                    }
                    break;
                case "html":
                    var o_arr = obj[ attr ];
                    for( var k in o_arr )
                    {
                        //try{ Id(k).innerHTML = o_arr[k]; }catch(E){/*alert(k + ":" + E);*/}
                        try{
                            if ( Id(k).innerHTML.charAt(0) == "+" || Id(k).innerHTML.charAt(0) == "-" )
                            {
                                Id(k).innerHTML = Id(k).innerHTML.charAt(0) + o_arr[k];
                            }
                            else
                            {
                                Id(k).innerHTML = o_arr[k];
                            }
                        }catch(E){/*alert(k + ":" + E);*/}
                    }
                    break;
                case "value":
                    var o_arr = obj[attr];
                    for(var k in o_arr)
                    {
                        try{ Id(k).value = o_arr[k]; }catch(E){/*alert(k + ":" + E);*/}
                    }
                    break;
                case "placeholder":
                    var o_arr = obj[ attr ];
                    for( var k in o_arr )
                    {
                        try{ Id(k).placeholder = o_arr[k]; }catch(E){/*alert(k + ":" + E);*/}
                    }
                    break;
                default:
                    //alert("unkown cmd: " + attr);
            }
        }
        catch(E){/*alert(obj + ":" + E);*/}
    }
}
/* standard context page show loading */
function Loading( note )
{
    var obj = {dialogClass: 'only-context',bgiframe: true,resizable: false,height:90,width:300,modal: true};
    $("#delay_loading_context").html(note);
    $("#delay_loading").dialog( obj );
}
/* cancal loading */
function Unloading( )
{
    $("#delay_loading").dialog( "close" );
}
/* standard context page confirm */
function Acknowledge( tl, cls, ok, note, cfunc, ofunc )
{
    var obj = {
        title: tl, bgiframe: true,resizable: false,height:160,width:300,modal: true, closeText: cls,
        buttons: [{
            text: ok,"id": "confirmOk",
            click: function(){ $("#ack_confirm").dialog( "close" );ofunc(); }
        }],
        open: function(){
            $(this).unbind( "keypress.ui-dialog" );
            $(this).bind( "keypress.ui-dialog", function(event){
                if (event.keyCode == $.ui.keyCode.ENTER) { $("#ack_confirm").dialog( "close" );ofunc(); }
            });
        },
        close: function(){$("#ack_confirm").dialog( "close" );cfunc()}
    };
    $("#ack_context").html(note);
    $("#ack_confirm").dialog( obj );
}
/* cancal loading */
function Uacknowledge( )
{
    $("#ack_confirm").dialog( "close" );
}
/* standard context page show context */
function Page( )
{
    if ( IsEmpty( Id("page_loading" ) ) == false )
    {
        Id("page_loading").style.visibility = "hidden";
        Id("page_loading").style.display = "none";
    }
    Id("page_body").style.visibility = "visible";
    Id("page_body").style.display = "";
    if ( top != null && top.SizeContext != null )
    {
        top.SizeContext();
    }
}
function Password2text( id, obj )
{
    try
    {
        if ( IsEmpty( id ) == false &&  IsEmpty( obj ) == false )
        {
            if ( Id(id).checked == true )
            {
                Id(obj).type = "text";
            }
            else
            {
                Id(obj).type = "password";
            }
        }
    }catch(E){}
}
function PasswordSwitch( id, obj, inputid )
{
    var tmp;
    try
    {
        if ( IsEmpty( id ) == false &&  IsEmpty( obj ) == false )
        {
            if ( IsEmpty( Id(inputid) ) == false )
            {
                tmp = EmptyToSpace( Id(inputid).value );
            }
            else
            {
                tmp = "";
            }
            if ( Id(id).checked == true )
            {
                Id(obj).innerHTML='<input type=text id="'+inputid+'" maxlength=64 />';
            }
            else
            {
                Id(obj).innerHTML='<input type=password id="'+inputid+'" maxlength=64 />';
            }
            Id(inputid).value = tmp;
        }
    }catch(E){}
}







/**//************************************************************************
public
*************************************************************************/
//var linkstatus = {"up":"连接成功", "uping":"正在连接", "down":"未连接"};
var linkstatus = {"up":"Connected", "uping":"Connecting", "down":"Disconnected"};

function lanShow( nmode, config, status )
{
    if ( nmode.indexOf("ap") >=0 || nmode.indexOf("repeater")  >=0 || nmode.indexOf("bridge") >=0 )
    {
        $("#div_dhcp").show();
        $("#div_gw").show();
        $("#div_dns").show();
        $("#div_dns2").show();
    }
    else
    {
        $("#div_dhcp").hide();
        $("#div_gw").hide();
        $("#div_dns").hide();
        $("#div_dns2").hide();
    }
    $("#mac").html( status.mac );

    if ( config.mode == "dhcpc" )
    {
        $("#dhcp").prop("checked", true);
        if ( config.dhcpc.static == "enable" )
        {
            $("#ipaddr").val( config.static.ipaddr.ip );
            $("#mask").val( config.static.ipaddr.mask );
            $("#gw").val( config.static.gw );
            $("#dns").val( config.static.dns );
            $("#dns2").val( config.static.dns2 );
        }
        if ( IsEmpty( status.ip ) == false && status.ip != config.static.ipaddr.ip )
        {
            $("#s_ipaddr").html( status.ip );
        }
        if ( IsEmpty( status.ip ) == false && status.mask != config.static.ipaddr.mask )
        {
            $("#s_mask").html( status.mask );
        }
        if ( IsEmpty( status.gw ) == false && status.ip != config.static.gw )
        {
            $("#s_gw").html( status.gw );
        }
        if ( IsEmpty( status.dns ) == false && status.ip != config.static.dns )
        {
            $("#s_dns").html( status.dns );
        }
        if ( IsEmpty( status.dns2 ) == false && status.ip != config.static.dns2 )
        {
            $("#s_dns2").html( status.dns2 );
        }
    }
    else
    {
        $("#dhcp").prop("checked", false);
        $("#ipaddr").val( config.static.ipaddr.ip );
        $("#mask").val( config.static.ipaddr.mask );
        $("#gw").val( config.static.gw );
        $("#dns").val( config.static.dns );
        $("#dns2").val( config.static.dns2 );
    }
}
function lanSave( nmode, config )
{
    var bakip;

    bakip = config.static.ipaddr.ip;

    if ( nmode.indexOf("ap") >=0 || nmode.indexOf("repeater")  >=0 || nmode.indexOf("bridge") >=0 )
    {
        if ( $("#dhcp").prop("checked") == true )
        {
            config.mode = "dhcpc";
            if ( IsEmpty( $("#ipaddr").val() ) == true )
            {
                config.dhcpc.static = "disable"
            }
            else
            {
                config.dhcpc.static = "enable"
                config.static.ipaddr.ip = $("#ipaddr").val();
                if ( IsIpAddress( config.static.ipaddr.ip ) == false )
                {
                    $("#ipaddr").css("color","red");
                    $("#ipaddr").select();
                    return null;
                }
                config.static.ipaddr.mask = $("#mask").val();
                if ( IsIpAddress( config.static.ipaddr.mask ) == false )
                {
                    $("#mask").css("color","red");
                    $("#mask").select();
                    return null;
                }
                config.static.gw = $("#gw").val();
                if ( IsEmpty( config.static.gw ) == false && IsIpAddress( config.static.gw ) == false )
                {
                    $("#gw").css("color","red");
                    $("#gw").select();
                    return null;
                }
                config.static.dns = $("#dns").val();
                if ( IsEmpty( config.static.dns ) == false && IsIpAddress( config.static.dns ) == false )
                {
                    $("#dns").css("color","red");
                    $("#dns").select();
                    return null;
                }
                config.static.dns2 = $("#dns2").val();
                if ( IsEmpty( config.static.dns2 ) == false && IsIpAddress( config.static.dns2 ) == false )
                {
                    $("#dns2").css("color","red");
                    $("#dns2").select();
                    return null;
                }
            }
        }
        else
        {
            config.mode = "static";
            config.static.ipaddr.ip = $("#ipaddr").val();
            if ( IsIpAddress( config.static.ipaddr.ip ) == false )
            {
                $("#ipaddr").css("color","red");
                $("#ipaddr").select();
                return null;
            }
            config.static.ipaddr.mask = $("#mask").val();
            if ( IsIpAddress( config.static.ipaddr.mask ) == false )
            {
                $("#mask").css("color","red");
                $("#mask").select();
                return null;
            }
            config.static.gw = $("#gw").val();
            if ( IsEmpty( config.static.gw ) == false && IsIpAddress( config.static.gw ) == false )
            {
                $("#gw").css("color","red");
                $("#gw").select();
                return null;
            }
            config.static.dns = $("#dns").val();
            if ( IsEmpty( config.static.dns ) == false && IsIpAddress( config.static.dns ) == false )
            {
                $("#dns").css("color","red");
                $("#dns").select();
                return null;
            }
            config.static.dns2 = $("#dns2").val();
            if ( IsEmpty( config.static.dns2 ) == false && IsIpAddress( config.static.dns2 ) == false )
            {
                $("#dns2").css("color","red");
                $("#dns2").select();
                return null;
            }
        }
    }
    else
    {
        config.static.ipaddr.ip = $("#ipaddr").val();
        if ( IsIpAddress( config.static.ipaddr.ip ) == false )
        {
            $("#ipaddr").css("color","red");
            $("#ipaddr").select();
            return null;
        }
        config.static.ipaddr.mask = $("#mask").val();
        if ( IsIpAddress( config.static.ipaddr.mask ) == false )
        {
            $("#mask").css("color","red");
            $("#mask").select();
            return null;
        }
    }

    /* dhcps */
    if ( bakip != config.static.ipaddr.ip )
    {
        var tmp;
        var iptmp;
        var starttmp;
        var endtmp;
        var startip;
        var endip;

        if ( IsEmpty( config.dhcps ) == true )
        {
            config.dhcps = new Object();
        }
        if ( IsEmpty( config.dhcps.startip ) == true )
        {
            config.dhcps.startip = "";
        }
        if ( IsEmpty( config.dhcps.endip ) == true )
        {
            config.dhcps.endip = "";
        }
        starttmp = config.dhcps.startip.split( "." );
        endtmp = config.dhcps.endip.split( "." );
        iptmp = config.static.ipaddr.ip.split( "." );
        tmp = config.static.ipaddr.mask.split( "." );
        /* 192 */
        startip = iptmp[0];
        endip = iptmp[0];
        /* 168 */
        if ( tmp[1] == "255" )
        {
            startip += ".";
            endip += ".";
            startip += iptmp[1];
            endip += iptmp[1];
        }
        else
        {
            startip += ".";
            endip += ".";
            if ( IsEmpty( starttmp[1] ) == false )
            {
                startip += starttmp[1];
            }
            else
            {
                startip += "0";
            }
            if ( IsEmpty( endtmp[1] ) == false )
            {
                endip += endtmp[1];
            }
            else
            {
                endip += "0";
            }
        }
        /* 2 */
        if ( tmp[2] == "255" )
        {
            startip += ".";
            endip += ".";
            startip += iptmp[2];
            endip += iptmp[2];
        }
        else
        {
            startip += ".";
            endip += ".";
            if ( IsEmpty( starttmp[2] ) == false )
            {
                startip += starttmp[2];
            }
            else
            {
                startip += "0";
            }
            if ( IsEmpty( endtmp[2] ) == false )
            {
                endip += endtmp[2];
            }
            else
            {
                endip += "0";
            }
        }
        /* 1 */
        startip += ".";
        endip += ".";
        if ( IsEmpty( endtmp[3] ) == false )
        {
            startip += starttmp[3];
        }
        else
        {
            startip += "2";
        }
        if ( IsEmpty( endtmp[3] ) == false )
        {
            endip += endtmp[3];
        }
        else
        {
            endip += "250";
        }
        config.dhcps.startip = startip;
        config.dhcps.endip = endip;
    }


    return config;
}

function wanShow( config, status )
{
    $("#status").html( linkstatus[status.status] );
    if ( IsEmpty( status.status ) == true || status.status == "disable" || status.status == "down" )
    {
        $("#status_up").show();
        $("#status_down").hide();
    }
    else
    {
        $("#status_up").hide();
        $("#status_down").show();
    }
    $("#status_mac").html( status.mac );
    if ( IsEmpty( status.ip ) == false )
    {
        $("#status_ip").html( status.ip );
    }
    if ( IsEmpty( status.gw ) == false )
    {
        $("#status_gw").html( status.gw );
    }
    if ( IsEmpty( status.dns ) == false )
    {
        if ( IsEmpty( status.dns2 ) == false )
        {
            $("#status_dns").html( status.dns+"/"+status.dns2 );
        }
        else
        {
            $("#status_dns").html( status.dns );
        }
    }
    if ( IsEmpty( status.tt_bytes ) == false )
    {
        //$("#status_tx").html( status.tt_bytes+"字节"+"/"+status.rt_bytes+"字节" );
        $("#status_tx").html( status.tt_bytes+"Byte"+"/"+status.rt_bytes+"Byte" );
    }

    if ( IsEmpty( config ) == false )
    {
        if ( IsEmpty( config.static ) == false )
        {
            $("#ipaddr").val( config.static.ipaddr.ip );
            $("#mask").val( config.static.ipaddr.mask );
            $("#gw").val( config.static.gw );
            $("#dns").val( config.static.dns );
            $("#dns2").val( config.static.dns2 );
        }
        if ( IsEmpty( config.pppoec ) == false )
        {
            $("#username").val( config.pppoec.username );
            $("#password").val( config.pppoec.password );
            $("#lcpi").val( config.pppoec.lcp_echo_interval );
            $("#lcpf").val( config.pppoec.lcp_echo_failure );
            $("#mtu").val( config.pppoec.mtu );
            $("#isp").val( config.pppoec.service );
        }
        if ( config.mode == "dhcpc" )
        {
             $("#li_dhcpc").addClass("active");
            $("#dhcpc").addClass("in active");
            $("#div_status_gw").show();
        }
        else if ( config.mode == "static" )
        {
            $("#li_static").addClass("active");
            $("#static").addClass("in active");
            $("#div_status_gw").show();
        }
        else if ( config.mode == "pppoec" )
        {
            $("#li_pppoec").addClass("active");
            $("#pppoec").addClass("in active");
        }
    }
}
function wanSave( config )
{
    if ( $("#li_dhcpc").hasClass("active") == true )
    {
        config.mode = "dhcpc";
    }
    else if ( $("#li_static").hasClass("active") == true )
    {
        if ( IsEmpty( config.static ) == true )
        {
            config.static = new Object();
        }
        if ( IsEmpty( config.static.ipaddr ) == true )
        {
            config.static.ipaddr = new Object();
        }
        config.mode = "static";
        config.static.ipaddr.ip = $("#ipaddr").val();
        if ( IsIpAddress( config.static.ipaddr.ip ) == false )
        {
            $("#ipaddr").css("color","red");
            $("#ipaddr").select();
            return null;
        }
        config.static.ipaddr.mask = $("#mask").val();
        if ( IsIpAddress( config.static.ipaddr.mask ) == false )
        {
            $("#mask").css("color","red");
            $("#mask").select();
            return null;
        }
        config.static.gw = $("#gw").val();
        if ( IsEmpty( config.static.gw ) == false && IsIpAddress( config.static.gw ) == false )
        {
            $("#gw").css("color","red");
            $("#gw").select();
            return null;
        }
        config.static.dns = $("#dns").val();
        if ( IsEmpty( config.static.dns ) == false && IsIpAddress( config.static.dns ) == false )
        {
            $("#dns").css("color","red");
            $("#dns").select();
            return null;
        }
        config.static.dns2 = $("#dns2").val();
        if ( IsEmpty( config.static.dns2 ) == false && IsIpAddress( config.static.dns2 ) == false )
        {
            $("#dns2").css("color","red");
            $("#dns2").select();
            return null;
        }
    }
    else if ( $("#li_pppoec").hasClass("active") == true )
    {
        config.mode = "pppoec";
        if ( IsEmpty( config.pppoec ) == true )
        {
            config.pppoec = new Object();
        }
        config.pppoec.username = $("#username").val();
        if ( IsEmpty( config.pppoec.username ) ==  true )
        {
            $("#username").css("color","red");
            $("#username").select();
            return null;
        }
        config.pppoec.password = $("#password").val();
        if ( IsEmpty( config.pppoec.password ) ==  true )
        {
            $("#password").css("color","red");
            $("#password").select();
            return null;
        }
        config.pppoec.service = $("#isp").val();
        config.pppoec.mtu = $("#mtu").val();
        if ( IsEmpty( config.pppoec.mtu ) ==  false && ( IsNumber( config.pppoec.mtu ) == false || config.pppoec.mtu < 128 || config.pppoec.mtu > 16384 ) )
        {
            $("#mtu").css("color","red");
            $("#mtu").select();
            return null;
        }
        config.pppoec.lcp_echo_interval = $("#lcpi").val();
        if ( IsEmpty( wan.pppoec.lcp_echo_interval ) ==  false && ( IsNumber( wan.pppoec.lcp_echo_interval ) == false ) )
        {
            $("#lcpi").css("color","red");
            $("#lcpi").select();
            return null;
        }
        config.pppoec.lcp_echo_failure = $("#lcpf").val();
        if ( IsEmpty( wan.pppoec.lcp_echo_failure ) ==  false && ( IsNumber( wan.pppoec.lcp_echo_failure ) == false ) )
        {
            $("#lcpf").css("color","red");
            $("#lcpf").select();
            return null;
        }
    }
    return config;
}

function ssidShow( config, id )
{
    if ( IsEmpty( config.status ) == false && config.status == "enable" )
    {
        $("#"+id+"_enable").prop("checked", true);
        $("#div_"+id).show();
    }
    else
    {
        $("#"+id+"_enable").prop("checked", false);
        $("#div_"+id).hide();
    }
    $("#"+id+"_ssid").val( config.ssid );
    $("#"+id+"_passwd").val( config.wpa_key );
    if ( IsEmpty( config.secure ) == true || config.secure == "disable" )
    {
        $("#"+id+"_security").prop("checked", false);
        $("#"+id+"_passwd").prop("disabled", true);
    }
    else
    {
        $("#"+id+"_security").prop("checked", true);
        $("#"+id+"_passwd").prop("disabled", false);
    }
    if ( IsEmpty( config.broadcast ) == true || config.broadcast == "enable" )
    {
        $("#"+id+"_hide").prop("checked", false)
    }
    else
    {
        $("#"+id+"_hide").prop("checked", true)
    }
}
function ssidSave( config, id )
{
    if ( $("#"+id+"_enable").prop("checked") == false )
    {
        config.status = "disable";
    }
    else
    {
        config.status = "enable";
        config.ssid = $("#"+id+"_ssid").val();
        if ( IsEmpty( config.ssid ) == true )
        {
            $("#"+id+"_ssid").css("color","red");
            $("#"+id+"_ssid").select();
            return null;
        }
        if ( $("#"+id+"_security").prop("checked") == true )
        {
            config.secure = "wpapskwpa2psk";
            config.wpa_encrypt = "aes";
            config.wpa_key = $("#"+id+"_passwd").val();
            if ( config.wpa_key.length < 8 || config.wpa_key.length > 64 )
            {
                $("#"+id+"_passwd").css("color","red");
                $("#"+id+"_passwd").select();
                return null;
            }
        }
        else
        {
            config.secure = "disable";
        }
        if ( $("#"+id+"_hide").prop("checked") == true )
        {
            config.broadcast = "disable";
        }
        else
        {
            config.broadcast = "enable";
        }
    }
    return config;
}

function bridgeShow( nconfig, nstat, aconfig, astat )
{
    var sconfig;
    var sstat;

    /* find the current radio */
    if ( IsEmpty( aconfig ) == false && aconfig.status == "enable" && IsEmpty( aconfig.peer ) == false )
    {
        sconfig = aconfig;
        sstat = astat;
    }
    else
    {
        sconfig = nconfig;
        sstat = nstat;
    }
    /* show the status */
    if ( IsEmpty( sstat ) == false )
    {
        $("#bridge_status").html( linkstatus[sstat.status] );
        $("#bridge_mac").html( sstat.mac );
        if ( IsEmpty( sstat.status ) == true || sstat.status == "disable" || sstat.status == "down" )
        {
            $("#bridge_txrx").html("");
            $("#bridge_signal").html("");
            $("#bridge_mac").val("");
            $("#bridge_up").show();
            $("#bridge_down").hide();
        }
        else
        {
            //$("#bridge_txrx").html( sstat.tt_bytes+"字节"+"/"+sstat.rt_bytes+"字节" );
            $("#bridge_txrx").html( sstat.tt_bytes+"Byte"+"/"+sstat.rt_bytes+"Byte" );
            if ( sstat.channel.length >= 4 )
            {
                if (typeof(sstat.signal) == "undefined")
                {
                    $("#bridge_signal").html( sstat.channel+"GHz"+"&nbsp;&nbsp;&nbsp;"+"--"+"dBm" );
                }
                else
                {
                    $("#bridge_signal").html( sstat.channel+"GHz"+"&nbsp;&nbsp;&nbsp;"+sstat.signal+"dBm" );
                }
            }
            else
            {
                if (typeof(sstat.signal) == "undefined")
                {
                    $("#bridge_signal").html( sstat.channel+"&nbsp;&nbsp;&nbsp;"+"--"+"dBm" );
                }
                else
                {
                    $("#bridge_signal").html( sstat.channel+"&nbsp;&nbsp;&nbsp;"+sstat.signal+"dBm" );
                }
            }
            $("#bridge_mac").val( sstat.peermac );
            $("#bridge_up").hide();
            $("#bridge_down").show();
        }
    }
    /* show the configure */
    $("#bridge_security").prop("checked", false);
    $("#bridge_passwd").prop("disabled", true);
    $("#bridge_lock").prop("checked", false);
    if ( IsEmpty( sconfig ) == false && IsEmpty( sconfig.peer ) == false )
    {
        $("#bridge_ssid").val( sconfig.peer );
        if ( IsEmpty( sconfig.peermac ) == false )
        {
            $("#bridge_bssid").val( sconfig.peermac );
            $("#bridge_lock").prop("checked", true);
        }
        if ( IsEmpty( sconfig.secure ) == true || sconfig.secure == "disable" )
        {
            $("#bridge_security").prop("checked", false);
            $("#bridge_passwd").prop("disabled", true);
        }
        else
        {
            $("#bridge_security").prop("checked", true);
            $("#bridge_passwd").prop("disabled", false);
        }
        /*
        if ( IsEmpty( sconfig.wds ) == false && sconfig.wds == "enable" )
        {
            $("#bridge_wds").prop("checked", true);
        }
        else
        {
            $("#bridge_wds").prop("checked", false);
        }
        */

        $("#bridge_passwd").val( sconfig.wpa_key );
    }
}
function bridgeSave( nconfig, ns, aconfig, as )
{
    var hi = 0;
    var he = new Array();
    var ss;
    var mm;
    var pp;
    // var ww;
    var save;
    var map;

    /* get all the configure setting */
    ss = $("#bridge_ssid").val();
    if ( IsEmpty( ss ) == true )
    {
        $("#bridge_ssid").css("color","red");
        $("#bridge_ssid").select();
        return null;
    }
    mm = "";
    if ( $("#bridge_lock").prop("checked") == true )
    {
        mm = $("#bridge_bssid").val();
        if ( IsEmpty( mm ) == false && IsMac(mm) == false )
        {
            $("#bridge_bssid").css("color","red");
            $("#bridge_bssid").select();
            return null;
        }
    }
    pp = "";
    if ( $("#bridge_security").prop("checked") == true )
    {
        pp = $("#bridge_passwd").val();
        if ( IsEmpty(pp) == true || pp.length < 8 || pp.length > 64 )
        {
            $("#bridge_passwd").css("color","red");
            $("#bridge_passwd").select();
            return null;
        }
    }
    /*
    if ( $("#bridge_wds").prop("checked") == true )
    {
        ww = "enable"
    }
    else
    {
        ww = "disable"
    }
    */

    /* clear the 2.4g 5g configure */
    if ( IsEmpty( aconfig ) == false )
    {
        aconfig.status = "disable";
        aconfig.peer = "";
        aconfig.peermac = "";
    }
    if ( IsEmpty( nconfig ) == false )
    {
        nconfig.status = "disable";
        nconfig.peer = "";
        nconfig.peermac = "";
    }

    /* find the current setting is 5G or 2.4G */
    if ( IsEmpty( nconfig ) == false && IsEmpty(aconfig) == false )
    {
        var m;
        /* if have mac */
        m = $("#bridge_bssid").val();
        if ( IsEmpty( m ) == false )
        {
            if ( IsEmpty( as ) == false && IsEmpty( as[m] ) == false )
            {
                save = aconfig;
                map = as[m];
            }
            else if ( IsEmpty( ns ) == false && IsEmpty( ns[m] ) == false )
            {
                save = nconfig;
                map = ns[m];
            }
            else
            {
                save = nconfig;
                map = null;
            }
        }
        /* or find the ssid is at 5g or 2.4g */
        else
        {
            var p;
            if ( IsEmpty( as ) == false )
            {
                for( p in as )
                {
                    if ( as[p].ssid == ss )
                    {
                        save = aconfig;
                        map = as[p];
                        break;
                    }
                }
            }
            if ( IsEmpty( ns ) == false )
            {
                for( p in ns )
                {
                    if ( ns[p].ssid == ss )
                    {
                        save = nconfig;
                        map = ns[p];
                        break;
                    }
                }
            }
        }
        if ( IsEmpty(save) == true )
        {
            save = nconfig;
        }
    }
    else if ( IsEmpty( nconfig ) == false )
    {
        var m;
        save = nconfig;
        m = $("#bridge_bssid").val();
        if ( IsEmpty( m ) == false && IsEmpty( ns ) == false && IsEmpty( ns[m] ) == false )
        {
            map = ns[m];
        }
        if ( IsEmpty( ns ) == false )
        {
            for( p in ns )
            {
                if ( ns[p].ssid == ss )
                {
                    save = nconfig;
                    map = ns[p];
                    break;
                }
            }
        }
    }
    else if ( IsEmpty( aconfig ) == false )
    {
        var m;
        save = aconfig;
        m = $("#bridge_bssid").val();
        if ( IsEmpty( m ) == false && IsEmpty( as ) == false && IsEmpty( as[m] ) == false )
        {
            map = as[m];
        }
        if ( IsEmpty( as ) == false )
        {
            for( p in as )
            {
                if ( as[p].ssid == ss )
                {
                    save = aconfig;
                    map = as[p];
                    break;
                }
            }
        }
    }

    /* save the configure */
    save.status = "enable";
    save.peer = ss;
    save.peermac = mm;
    // save.wds = ww;
    if ( IsEmpty( pp ) == false )
    {
        if ( IsEmpty( map ) == false )
        {
            save.secure = map.secure;
            save.wpa_encrypt = map.wpa_encrypt;
        }
        else
        {
            if ( IsEmpty( save.secure ) == true || save.secure == "disable" )
            {
                save.secure = "wpa2psk";
            }
            if ( IsEmpty( save.wpa_encrypt ) == true )
            {
                save.wpa_encrypt = "aestkip";
            }
        }
        save.wpa_key = pp;
    }
    else
    {
        save.secure = "disable";
        save.wpa_encrypt = "";
        save.wpa_key = "";
    }

    if ( IsEmpty( nconfig ) == false )
    {
        he[hi++] = "radio11n/sta="+JsonString( nconfig )
    }
    if ( IsEmpty( aconfig ) == false )
    {
        he[hi++] = "radio11a/sta="+JsonString( aconfig )
    }
    return he;
}




//var simstatus = {"ready":"连接成功", "failed":"无SIM卡", "pin":"SIM卡PIN码错误"};
var simstatus = {"ready":"Connected", "failed":"No SIM", "pin":"SIM's PIN error"};
function lteShow( config, status, usb )
{
    $("#status").html( linkstatus[status.status] );
    if ( IsEmpty( status.status ) == true || status.status == "disable" || status.status == "down" )
    {
        $("#status_up").show();
        $("#status_down").hide();
    }
    else
    {
        $("#status_up").hide();
        $("#status_down").show();
    }
    if ( IsEmpty( usb.simcard ) == true )
    {
        $("#status_network").html( simstatus["failed"] );
    }
    else
    {
        $("#status_network").html( simstatus[usb.simcard] );
    }

    if ( IsEmpty( usb.operator ) == false )
    {
        $("#status_network").html( usb.operator.name );
    }
    $("#status_signal").html( usb.signal );

    $("#status_ip").html( status.ip );
    $("#status_gw").html( status.gw );
    if ( IsEmpty( status.dns ) == false )
    {
        if ( IsEmpty( status.dns2 ) == false )
        {
            $("#status_dns").html( status.dns+"/"+status.dns2 );
        }
        else
        {
            $("#status_dns").html( status.dns );
        }
    }
    if ( IsEmpty( status.tt_bytes ) == false )
    {
        $("#status_tx").html( status.tt_bytes+"Byte"+"/"+status.rt_bytes+"Byte" );
    }

    if ( IsEmpty( config.ppp ) == false )
    {
        var op;
        var pppcfg = config.ppp;
        $("#lcpi").val( pppcfg.lcp_echo_interval );
        $("#lcpf").val( pppcfg.lcp_echo_failure );
        $("#mtu").val( pppcfg.mtu );
        $("#opt").val( pppcfg.pppopt );
        if ( pppcfg.oper == "enable" )
        {
            $("#operator").prop("checked", true)
            $("#dialnumber").prop("disabled", false);
            $("#apn").prop("disabled", false);
            $("#username").prop("disabled", false);
            $("#password").prop("disabled", false);
            op = pppcfg.operator;
        }
        else
        {
            $("#operator").prop("checked", false)
            $("#dialnumber").prop("disabled", true);
            $("#apn").prop("disabled", true);
            $("#username").prop("disabled", true);
            $("#password").prop("disabled", true);
            op = usb.operator;
        }
        if ( IsEmpty( op ) == false )
        {
            $("#dialnumber").val( op.dial );
            $("#apn").val( op.apn );
            $("#username").val( op.user );
            $("#password").val( op.passwd );
        }
    }
}
function lteSave( config )
{
    if ( IsEmpty( config.ppp ) == true )
    {
        config.ppp = new Object();
    }
    var pppcfg = config.ppp;
    pppcfg.lcp_echo_interval = $("#lcpi").val();
    pppcfg.lcp_echo_failure = $("#lcpf").val();
    pppcfg.mtu = $("#mtu").val();
    pppcfg.pppopt = $("#opt").val();
    if ( $("#operator").prop("checked") == true )
    {
        pppcfg.oper = "enable";
        if ( IsEmpty( pppcfg.operator ) == true )
        {
            pppcfg.operator = new Object();
        }
        var op = pppcfg.operator;
        op.dial = $("#dialnumber").val();
        if ( IsEmpty( op.dial ) ==  true )
        {
            $("#dialnumber").css("color","red");
            $("#dialnumber").select();
            return null;
        }
        op.apn = $("#apn").val();
        op.user = $("#username").val();
        op.passwd = $("#password").val();
    }
    else
    {
        pppcfg.oper = "disable";
    }
    return config;
}
