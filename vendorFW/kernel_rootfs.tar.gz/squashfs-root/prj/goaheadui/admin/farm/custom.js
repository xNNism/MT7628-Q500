// reboot process bar
var rebootTime = 600;

var processInterval = rebootTime;
var processTimeer = 0;
var processTick = 0;

function processLoop( )
{
    processTick++; 
    $("#lpcProcess").width(processTick+"%");
    $("#processTitle").html( "Rebooting..."+" "+processTick+"%" );

    if ( processTick == 1)
    {
        He( "machine.restart", function(){} );
    }
    if (processTick < 100) 
    { 
        setTimeout( "processLoop( )", processInterval );
    } 
    else
    {
        clearTimeout(processTimeer);
        bootbox.confirm("Make sure that the device is reconnected?", function(result)
        {
            if ( IsEmpty( top ) == false && top.Reload != null )
            {
                top.Reload();
            }
            else
            {
                window.location.href = "http://"+location.host +"/"+location.pathname;
            }
        });
    }
}
/* reboot the device */
function deviceReboot()
{
    $("#context").hide();
    $("#process").show();

    $("#processNote").html("Reboot starting, please wait");

    processLoop( );
}

/*
 * clients modal table, must define function of window.clientSelectCallback
 * for example
	window.clientSelectCallback = function( mac ){
		$("#src").val( mac );
	};                    	
 * defaultSelect: IP, MAC
 * lang: cn, en
 */

function clientsModalTable( id, defaultSelect, lang )
{
	var words = {
		cn:{clientsList:"客户端列表", name:"名称", operation:"操作", selectClient:"选择"},
		en:{clientsList:"Clients List", name:"Name", operation:"Operation", selectClient:"Select"}
	}
	
	// parameter check
	if( "cn" !== lang && "en" !== lang )
	{
		lang = "cn";
	}
	
	// waiting
	$("#scan_loading").remove();
	$("#"+id).after("<i class=\"ace-icon ace-icon-custom fa fa-spinner fa-spin orange bigger-125\" id=\"scan_loading\" style=\"display:none\"></i>");
	
	// modal table
	$("#modal-table").remove();
	$("body").append(
		"<div id=\"modal-table\" class=\"modal\">"+
		"	<div class=\"modal-dialog\">"+
		"		<div class=\"modal-content\">"+
		"			<div class=\"modal-header no-padding\">"+
		"				<div class=\"table-header dark\" style=\"background-color: #FFF;\">"+
		"					<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">"+
		"						<span>&times;</span>"+
		"					</button>"+
		"					"+words[lang].clientsList+"(<span id=\"number\">0</span>)"+
		"				</div>"+
		"			</div>"+
		"			<div class=\"modal-body no-padding\">"+
		"				<table id=\"client_table\" class=\"table table-striped table-bordered table-hover table-condensed no-margin-bottom no-margin-top\">"+
		"					<thead>"+
		"						<tr>"+
		"							<th>"+words[lang].name+"</th>"+
		"							<th>MAC</th>"+
		"							<th class=\"hidden-480\">IP</th>"+
		"							<th>"+words[lang].operation+"</th>"+
		"						</tr>"+
		"					</thead>"+
		"					<tbody>"+
		"					</tbody>"+
		"				</table>"+
		"			</div>"+
		"			<div class=\"modal-footer\">"+
		"				<button id=\"modalClose\" type=\"button\" class=\"btn btn-default\" data-dismiss=\"modal\">关闭</button>"+
		"			</div>"+
		"		</div>"+
		"		<!-- /.modal-content -->"+
		"	</div>"+
		"	<!-- /.modal-dialog -->"+
		"</div>"+
		"<!-- /.modal -->"
	);
	
    $("#"+id).hide();
    $("#scan_loading").show();
	He( {0:"network/station.list"}, function( v )
	{
		$("#scan_loading").hide();
        $("#"+id).show();
        
        // show clients
        var i;
        var p;
        var trtext;
        var trherf;
        var c;
        var list = v[0];

        i = 0;
        
        
        $("#client_table tr:not(:first)").empty("");
        if ( IsEmpty( list ) == true )
        {
            return;
        }
        for( p in list )
        {
        	i++;
            trtext = "";
            trherf = "";

            c = list[p];

            /* don't show the no lan client  */
            if ( c.ifname == "ifname/wan" )
            {
                continue;
            }
            
            trherf = " onClick='clientView(\""+p+"\")' ";

            /* tr show */
            if ( c.livetime == "none" )
            {
                trtext += "<tr style='background:#cccccc' >";
            }
            else
            {
                trtext += "<tr style='background:#ffffff'>";
            }
            /* name */
            trtext += "<td"+trherf+">"+EmptyToSpace(c.hostname)+"</td>";
        
            /* mac */
            trtext += "<td"+trherf+">"+p+"</td>";

            /* IP */
            trtext += "<td"+trherf+"class='hidden-480'>"+EmptyToSpace(c.ip)+"</td>";

            /* operation */
           if( "IP" == defaultSelect )
           {
           		 trtext += "<td><button class='btn btn-sm btn-info' type='button' data-dismiss='modal'" + " onClick='clientSelectCallback(\""+c.ip+"\")'>"+words[lang].selectClient+"</button></td>";
           }
           else
           {
           		 trtext += "<td><button class='btn btn-sm btn-info' type='button' data-dismiss='modal'" + " onClick='clientSelectCallback(\""+p+"\")'>"+words[lang].selectClient+"</button></td>";
           }
            
            trtext += "</tr>";
            $("#client_table tr:last").after(trtext);
        }
        $("#number").html( i );
        
        // show modal
		$("#modal-table").modal();
	});
}


