{
    login:
    {
        title:"Device Login",
        user:"Username",
        password:"Password",
        login:"Login",
        warn:"Please input correct username and password",
	not_support:"It is recommended to use Internet explorer 8 or above or Google Chrome or Firefox browser",
	remember:"Remember me"
    },
    index:
    {
        title:"Management",
        en:"English",
        cn:"Chinese Simplified",
        tw:"Chinese Traditional",
        logout:"Exit"
    },
    menu:
    {
        html:
        {
            in_client:"Clients",
            in_client_list:"Local Clients",

            in_wisp:"WISP",
            in_bridge:"Bridge",

            in_mode:"Operation Mode",
	    
            in_wizard:"Wizard",

            in_wireless:"Wireless 11N",
            in_ssid:"Basic",
            in_mssid:"MSSID",
            in_wifi:"Advanced",
            in_wds:"WDS",

            in_wireless_ac:"Wireless 11AC",
            in_ssid_ac:"Basic",
            in_mssid_ac:"MSSID",
            in_wifi_ac:"Advanced",
            in_wds_ac:"WDS",

            in_network:"Network",
            in_wan:"WAN",
            in_lan:"IP Address",
            in_upnp:"UPNP",

            in_system:"System",
            in_manger:"Management",
            in_user:"User",
            in_clock:"Date",
            in_restart:"Smart Restart",

            in_tools:"Debug",
            in_log:"Log",
            in_dhcps:"DHCP Server",
            in_nat:"NAT",
            in_macclone:"MAC Clone",
            in_route:"Route Rule",
            in_tc:"TC",
            in_acl:"ACL",
            in_ftp:"FTP Server",
            in_samba:"SAMBA Server",
            in_ipupdate:"DDNS",

            in_logout:"Logout"
        }
    }
}

