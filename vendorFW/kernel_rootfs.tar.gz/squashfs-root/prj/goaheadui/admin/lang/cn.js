{
    login:
    {
        title:"设备登录",
        user:"用户名",
        password:"密码",
        login:"登录",
        warn:"请输入正确的用户名及口令",
	not_support:"建议使用IE8及以上或Google Chrome或Firefox的浏览器",
	remember:"记住我"
    },
    index:
    {
        title:"设备管理",
        en:"English",
        cn:"简体中文",
        tw:"繁体中文",
        logout:"退出"
    },
    menu:
    {
        html:
        {
            in_client:"客户端",
            in_client_list:"客户端列表",

            in_wisp:"无线连网(WISP)",
            in_bridge:"无线网桥",

            in_mode:"工作模式",

            in_wizard:"普通用户设置",


            in_wireless:"无线11N",
            in_ssid:"基本设置",
            in_mssid:"虚拟SSID",
            in_wifi:"高级设置",
            in_wds:"无线分布式",

            in_wireless_ac:"无线11AC",
            in_ssid_ac:"基本设置",
            in_mssid_ac:"虚拟SSID",
            in_wifi_ac:"高级设置",
            in_wds_ac:"无线分布式",

            in_network:"网络设置",
            in_wan:"互联网接入",
            in_lan:"本地设置",

            in_system:"系统管理",
            in_manger:"设备管理",
            in_user:"用户设置",
            in_clock:"时间设置",
            in_restart:"自动重启",

            in_tools:"调试工具",
            in_log:"日志管理",
            in_dhcps:"DHCP服务器",
            in_nat:"端口映射",
            in_macclone:"MAC地址克隆",
            in_route:"路由表管理",
            in_tc:"流量控制",
            in_acl:"访问控制",
            in_ftp:"FTP服务器",
            in_samba:"SAMBA服务器",
            in_oray:"花生壳动态域名",
            in_ipupdate:"动态域名",
            in_upnp:"UPNP",

            in_logout:"退出登录"
        }
    }
}

