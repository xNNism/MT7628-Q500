function myId()
{
    var elements = new Array();

    for(var i = 0; i < arguments.length; i++)
    {
        var element = arguments[i];

        if(typeof element == 'string')
        {
            if(document.getElementById)
            {
                element = document.getElementById(element);
            }
            else if(document.all)
            {
                element = document.all[element];
            }
        }

        elements.push(element);
    }

    if(arguments.length == 1 && elements.length > 0)
    {
        return elements[0];
    }
    else
    {
        return elements;
    }
}

function dispalyObj(obj, show)
{
    var isIE = (navigator.appName == "Microsoft Internet Explorer");

    if(isIE)
    {
        try
        {
            obj.style.display = show ? "block" : "none";
        } catch(E){}
    }
    else
    {
        try
        {
            obj.style.display = show ? "block" : "none";
         //obj.style.visibility = show ? "visible" : "collapse";
        } catch(E){}
    }

    if(show)
    {
        obj.style.visibility = "visible";
    }
}

function addEvent(obj, evt, fn)
{
    try
    {
        obj.addEventListener(evt, fn, false);
        return true;
    } catch(E) {}

    try 
    {
        obj.attachEvent("on"+evt, fn);
        return true;
    } catch(E) {}
    return false;
}

function getEventElement(e)
{
    if(e.srcElement)
    {
        return e.srcElement;
    }
    else if(e.originalTarget)
    {
        return e.originalTarget;
    }

    return null;
}

var menu_list = [];
function addMenuEvent(name_src, name_dst)
{
    try
    {
        var obj_src = myId(name_src);
        var obj_dst = myId(name_dst);

        obj_src.innerHTML = "+ " + obj_src.innerHTML;
        obj_dst.setAttribute("show", "false");
        obj_src.setAttribute("obj_name", name_dst);
        dispalyObj(obj_dst, false);
        addEvent(obj_src, "click", showHideMeun);
        menu_list.push(obj_src);
    }
    catch(e)
    {
        alert(e);
    }
}

function showHideMeun(e)
{
    var p, src, dst;
    var obj_src = getEventElement(e);

    try
    {
        var obj_dst = myId(obj_src.getAttribute("obj_name"));

        if(obj_dst.getAttribute("show") == "false")
        {
            obj_dst.setAttribute("show", "true");
            dispalyObj(obj_dst, true);
            obj_src.innerHTML = obj_src.innerHTML.replace("+", "-");
        }
        else
        {
            dispalyObj(obj_dst, false);
            obj_dst.setAttribute("show", "false");
            obj_src.innerHTML = obj_src.innerHTML.replace("-", "+");
        }
    }
    catch(e)
    {
        alert(e);
    }

    /* hide other */
    for( p in menu_list )
    {
        src = menu_list[p];
        if ( src != obj_src )
        {
            var dst = myId(src.getAttribute("obj_name"));
            if(dst.getAttribute("show") == "true")
            {
                dispalyObj(dst, false);
                dst.setAttribute("show", "false");
                src.innerHTML = src.innerHTML.replace("-", "+");
            }
        }
    }
    
}

function expendMenu( name_src, name_dst )
{
    var obj_src = myId( name_src );

    try
    {
        var obj_dst = myId( name_dst );

        if(obj_dst.getAttribute("show") == "false")
        {
            obj_dst.setAttribute("show", "true");
            dispalyObj(obj_dst, true);
            obj_src.innerHTML = obj_src.innerHTML.replace("+", "-");
        }
        else
        {
            dispalyObj(obj_dst, false);
            obj_dst.setAttribute("show", "false");
            obj_src.innerHTML = obj_src.innerHTML.replace("-", "+");
        }
    }
    catch(e)
    {
        alert(e);
    }
}

