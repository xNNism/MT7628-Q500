#!/bin/sh
append DRIVERS "mt7612e"

. /lib/wifi/ralink_common.sh

prepare_mt7612e() {
	prepare_ralink_wifi mt7612e
}

scan_mt7612e() {
	scan_ralink_wifi mt7612e mt76x2e
}

disable_mt7612e() {
	disable_ralink_wifi mt7612e
}

enable_mt7612e() {
	enable_ralink_wifi mt7612e mt76x2e
}

detect_mt7612e() {
#	detect_ralink_wifi mt7612e mt76x2e
	ssid=mt7612e-`ifconfig eth0 | grep HWaddr | cut -c 51- | sed 's/://g'`
	cd /sys/module/
	[ -d $module ] || return
	[ -e /etc/config/wireless ] && return
	 cat <<EOF
config wifi-device      mt7612e
	option type 'mt7612e'
	option vendor 'ralink'
	option band '5G'
	option channel '0'
        option autoch   2
	option wifimode '14'
	option bgprotect '0'
	option beacon '100'
	option dtim '1'
	option fragthres '2346'
	option rtsthres '2347'
	option txpower '100'
	option txpreamble '1'
	option txburst '1'
	option noforward '0'
	option wmm '0'
	option bw '1'
	option vht_bw '1'
	option ht_bsscoexist '0'
	option accesspolicy0 '0'
	option wds_enable '0'
	option country 'CN'
	option aregion '4'

config wifi-iface 'rai0'
	option device 'mt7612e'
	option ifname 'rai0'
	option network 'lan'
	option mode 'ap'
	option ssid 'AFOUNDRY-5.8G'
	option encryption 'psk2+ccmp'
	option key '88888888'
	option disabled '0'
	option hidden '0'

config wifi-iface 'rai1'
	option device 'mt7612e'
	option ifname 'rai1'
	option network 'lan'
	option mode 'ap'
	option ssid 'MSSID1'
	option encryption 'psk2+ccmp'
	option key '88888888'
	option disabled '1'
	option hidden '0'

config wifi-iface 'rai2'
	option device 'mt7612e'
	option ifname 'rai2'
	option network 'lan'
	option mode 'ap'
	option ssid 'MSSID2'
	option encryption 'psk2+ccmp'
	option key '88888888'
	option disabled '1'
	option hidden '0'

config wifi-iface 'rai3'
	option device 'mt7612e'
	option ifname 'rai3'
	option network 'lan'
	option mode 'ap'
	option ssid 'MSSID3'
	option encryption 'psk2+ccmp'
	option key '88888888'
	option disabled '1'
	option hidden '0'

config wifi-iface 'apclii0'
	option device 'mt7612e'
	option ifname 'apclii0'
	option network 'lan'
	option mode    'sta'
	option disabled '1'
	option apcli_enable '0'
	option apcli_ssid ''
	option apcli_bssid ''
	option apcli_authmode 'OPEN'
	option apcli_encryptype 'NONE'

config wifi-iface 'wdsi0'
	option device 'mt7612e'
	option ifname 'wdsi0'
	option network 'lan'
	option mode 'wds'

config wifi-iface 'wdsi1'
	option device 'mt7612e'
	option ifname 'wdsi1'
	option network 'lan'
	option mode 'wds'

config wifi-iface 'wdsi2'
	option device 'mt7612e'
	option ifname 'wdsi2'
	option network 'lan'
	option mode 'wds'

config wifi-iface 'wdsi3'
	option device 'mt7612e'
	option ifname 'wdsi3'
	option network 'lan'
	option mode 'wds'

EOF

}


