#!/bin/sh

ONLINEINFO="{\"mode\":\"ppp\",\"device\":\"${1}\",\"ifname\":\"${3}\",\"gw\":\"${4}\",\"dns\":\"${5}\",\"dns2\":\"${6}\"}"
he "network/frame.online[${ONLINEINFO}]"
 
